import React from "react";
export default function Branch(){
    return(
        <>
        <div className="branch">
            
            </div>
            </>
    )
}